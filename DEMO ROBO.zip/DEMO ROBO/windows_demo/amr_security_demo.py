"""Demo visual local para Windows. Simulação didática, não controla hardware real."""
import argparse
import math
import os
import time
import tkinter as tk
from tkinter import ttk

MAX_LINEAR = 0.45       # m/s
MAX_ANGULAR = 1.2       # rad/s
MAX_ACCEL = 3.8         # m/s² (limite didático)
DT = 0.1

def is_gui_available():
    if os.name == "nt":
        return True
    return bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))


def headless_mode(iterations=8, delay=0.1):
    demo = Demo.__new__(Demo)
    demo.last_v = 0.0
    messages = []
    for i in range(iterations):
        attack = i % 4 == 0
        cmd_v, cmd_w = (1.8, 2.0) if attack else (0.25, 0.15)
        ok, reason = demo.validate(cmd_v, cmd_w, max(0.01, min(0.25, delay)))
        status = "ATTACK_BLOCKED" if attack and not ok else "NORMAL"
        if ok:
            demo.last_v = cmd_v
        else:
            demo.last_v = 0.0
        messages.append(
            f"STATUS {status} | ataque={str(attack).upper()} | v={cmd_v:.2f} | ok={ok} | {reason}"
        )
        time.sleep(delay)
    return messages


class Demo:
    def __init__(self, root):
        self.root = root
        root.title("Cyber-Physical AMR Security Lab — Demo local")
        root.geometry("1200x760")
        root.minsize(1100, 680)
        root.configure(bg="#0b1220")
        self.style = ttk.Style(root)
        self.style.theme_use("clam")
        self.style.configure("Header.TFrame", background="#08101c")
        self.style.configure("Panel.TFrame", background="#101827")
        self.style.configure("Accent.TButton", background="#1f9d8b", foreground="#ffffff", padding=(12, 8), font=("Segoe UI", 10, "bold"))
        self.style.map("Accent.TButton", background=[("active", "#1a8d7a")])
        self.style.configure("TLabel", background="#101827", foreground="#e5eefb")
        self.style.configure("TFrame", background="#101827")
        self.style.configure("TLabelframe", background="#101827")
        self.style.configure("TLabelframe.Label", background="#101827", foreground="#dfe9ff", font=("Segoe UI", 10, "bold"))
        self.attack = False
        self.x, self.y, self.theta = 110.0, 230.0, 0.0
        self.v = 0.0
        self.last_v = 0.0
        self.last_time = time.monotonic()
        self.blocked = 0
        self.accepted = 0
        self.status = "NORMAL"
        self.last_reason = "Nenhuma violação detectada"
        self.bridge_status = "Bridge ROS/Gazebo pronto"
        self.command_path = "cmd_vel_untrusted -> sentinela -> cmd_vel"
        self.obstacles = [
            (195, 55, 255, 125),
            (315, 55, 375, 125),
            (435, 55, 495, 125),
            (555, 55, 615, 125),
            (195, 275, 255, 345),
            (315, 275, 375, 345),
            (435, 275, 495, 345),
            (555, 275, 615, 345),
        ]
        self.history = [(self.x, self.y)]
        self.build_ui()
        self.tick()

    def build_ui(self):
        top = ttk.Frame(self.root, padding=14, style="Header.TFrame")
        top.pack(fill="x")
        ttk.Label(top, text="CYBER-PHYSICAL AMR SECURITY LAB",
                  font=("Segoe UI", 20, "bold"), foreground="#ecf3ff").pack(anchor="w")
        ttk.Label(top, text="Demonstração didática de injeção de comandos, validação de política e mitigação segura",
                  foreground="#b8c8e8").pack(anchor="w")

        controls = ttk.Frame(self.root, padding=(12, 8, 12, 6), style="Panel.TFrame")
        controls.pack(fill="x")
        ttk.Button(controls, text="Iniciar ataque", command=self.start_attack, width=18, style="Accent.TButton").pack(side="left", padx=4)
        ttk.Button(controls, text="Parar ataque", command=self.stop_attack, width=18, style="Accent.TButton").pack(side="left", padx=4)
        ttk.Button(controls, text="Resetar", command=self.reset, width=18, style="Accent.TButton").pack(side="left", padx=4)
        self.status_label = ttk.Label(controls, text="STATUS: NORMAL", font=("Segoe UI", 11, "bold"), foreground="#d9fbe5")
        self.status_label.pack(side="right", padx=10)

        content = ttk.Frame(self.root, style="Panel.TFrame")
        content.pack(fill="both", expand=True, padx=12, pady=(0, 10))

        left = ttk.Frame(content, style="Panel.TFrame")
        left.pack(side="left", fill="both", expand=True)
        self.canvas = tk.Canvas(left, width=780, height=440, bg="#edf5fb",
                                highlightthickness=1, highlightbackground="#d0d7e2")
        self.canvas.pack(padx=(0, 8), pady=(0, 6), fill="both", expand=True)

        self.canvas.create_rectangle(25, 30, 755, 390, outline="#5d6777", width=2, fill="#f8fafc")
        self.canvas.create_text(60, 18, text="ARMAZÉM VIRTUAL — simulação local / preparação para bridge Gazebo", anchor="w", fill="#374151", font=("Segoe UI", 10, "bold"))

        for x in range(50, 760, 45):
            self.canvas.create_line(x, 30, x, 390, fill="#dfe7f1", width=1)
        for y in range(40, 370, 35):
            self.canvas.create_line(25, y, 755, y, fill="#dfe7f1", width=1)

        self.canvas.create_rectangle(55, 165, 125, 225, fill="#dbeafe", outline="#2563eb", width=2)
        self.canvas.create_text(90, 195, text="DOCK", fill="#1d4ed8", font=("Segoe UI", 8, "bold"))
        self.canvas.create_rectangle(665, 300, 715, 345, fill="#fef3c7", outline="#d97706", width=2)
        self.canvas.create_text(690, 290, text="META", fill="#92400e", font=("Segoe UI", 8, "bold"))

        for x1, y1, x2, y2 in self.obstacles:
            self.canvas.create_rectangle(x1, y1, x2, y2, fill="#b8bec8", outline="#6b7280", width=2)
            self.canvas.create_text((x1 + x2) / 2, (y1 + y2) / 2, text="RACK", fill="#374151", font=("Segoe UI", 8, "bold"))

        self.canvas.create_rectangle(650, 55, 730, 125, fill="#e2e8f0", outline="#475569", width=2)
        self.canvas.create_text(690, 90, text="CARGA", fill="#334155", font=("Segoe UI", 9, "bold"))
        self.canvas.create_rectangle(135, 150, 635, 250, fill="#edf2f7", outline="#64748b", width=2)
        self.canvas.create_text(385, 165, text="CORREDOR PRINCIPAL", fill="#334155", font=("Segoe UI", 9, "bold"))

        self.canvas.create_text(60, 350, text="Fluxo: comando não confiável → sentinela → comando validado", anchor="w", fill="#455", font=("Segoe UI", 9, "bold"))
        self.route_line = self.canvas.create_line(self.x, self.y, self.x, self.y, fill="#4a90e2", width=4, smooth=True)
        self.goal_marker = self.canvas.create_oval(678, 307, 702, 331, fill="#f59e0b", outline="#b45309", width=2)
        self.robot = self.canvas.create_oval(self.x-18, self.y-18, self.x+18, self.y+18,
                                             fill="#218838", outline="#145523", width=3)
        self.heading = self.canvas.create_line(self.x, self.y, self.x+30, self.y,
                                               fill="#145523", width=5, arrow=tk.LAST)

        right = ttk.Frame(content, padding=(0, 0, 0, 0), style="Panel.TFrame")
        right.pack(side="right", fill="y")
        self.panel = ttk.Frame(right, padding=8, style="Panel.TFrame")
        self.panel.pack(fill="both", expand=True)

        cards = [
            ("Telemetria de segurança", [
                ("status", ttk.Label(self.panel, text="Status: NORMAL", font=("Segoe UI", 11, "bold"), foreground="#1b7f45")),
                ("bridge", ttk.Label(self.panel, text="Bridge: pronto", foreground="#375a7f")),
                ("accepted", ttk.Label(self.panel, text="Aceitos: 0", foreground="#1b7f45")),
                ("blocked", ttk.Label(self.panel, text="Bloqueados: 0", foreground="#c0392b")),
            ]),
            ("Fluxo do sistema", [
                ("route", ttk.Label(self.panel, text="Caminho: cmd_vel_untrusted -> sentinela -> cmd_vel", wraplength=260, justify="left")),
                ("sim", ttk.Label(self.panel, text="Integração: Gazebo / ROS 2 pronta para bridge", wraplength=260, justify="left")),
            ]),
            ("Política e motivo", [
                ("policy", ttk.Label(self.panel, text="Política: |v| ≤ 0.45 m/s | |ω| ≤ 1.20 rad/s | acel. ≤ 3.80 m/s²", wraplength=260, justify="left")),
                ("reason", ttk.Label(self.panel, text="Motivo: Nenhuma violação detectada", wraplength=260, justify="left")),
            ]),
        ]

        self.metrics = {}
        for title, widgets in cards:
            card = ttk.LabelFrame(self.panel, text=title, padding=10, style="TLabelframe")
            card.pack(fill="x", pady=(0, 8))
            for key, widget in widgets:
                widget.pack(anchor="w", pady=2)
                self.metrics[key] = widget

        self.panel.bind("<Configure>", lambda event: None)

        self.info = ttk.Label(self.root, padding=(10, 8), text="", font=("Segoe UI", 10, "bold"), background="#0b1220")
        self.info.pack(fill="x")

        log_frame = ttk.LabelFrame(self.root, text="Log de eventos", padding=(10, 8), style="Panel.TFrame")
        log_frame.pack(fill="x", padx=15, pady=(0, 12))
        self.log = tk.Text(log_frame, height=6, state="disabled", font=("Consolas", 9), bg="#f9fafb")
        self.log.pack(fill="x")
        self.write_log("Sistema iniciado. Gateway de segurança ativo; a simulação está pronta para integração com ROS/Gazebo.")

    def write_log(self, msg):
        self.log.configure(state="normal")
        self.log.insert("end", f"[{time.strftime('%H:%M:%S')}] {msg}\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def start_attack(self):
        self.attack = True
        self.status = "ATTACK_TEST"
        self.last_reason = "Origem simulada iniciou injeção controlada de velocidade fora da política"
        self.write_log("Teste de injeção iniciado: origem simulada envia velocidade fora da política.")

    def stop_attack(self):
        self.attack = False
        self.status = "NORMAL"
        self.last_reason = "Origem de comandos voltou ao perfil seguro"
        self.write_log("Teste encerrado. Origem de comandos voltou ao perfil seguro.")

    def reset(self):
        self.attack = False
        self.x, self.y, self.theta, self.v = 110.0, 230.0, 0.0, 0.0
        self.last_v = 0.0
        self.blocked = self.accepted = 0
        self.status = "NORMAL"
        self.last_reason = "Estado da demonstração reiniciado"
        self.history = [(self.x, self.y)]
        self.write_log("Estado da demonstração reiniciado.")

    def validate(self, linear, angular, dt):
        # Função pura: mesma entrada -> mesma saída; não altera estado nem interface.
        if not all(math.isfinite(n) for n in (linear, angular, dt)) or dt <= 0:
            return False, "valor não finito ou intervalo inválido"
        if abs(linear) > MAX_LINEAR:
            return False, f"velocidade linear {linear:.2f} excede ±{MAX_LINEAR:.2f} m/s"
        if abs(angular) > MAX_ANGULAR:
            return False, f"velocidade angular {angular:.2f} excede ±{MAX_ANGULAR:.2f} rad/s"
        accel = abs(linear - self.last_v) / dt
        if accel > MAX_ACCEL:
            return False, f"aceleração {accel:.2f} excede {MAX_ACCEL:.2f} m/s²"
        return True, "comando aceito"

    def tick(self):
        now = time.monotonic()
        dt = max(0.01, min(0.25, now - self.last_time))
        self.last_time = now
        if self.attack:
            cmd_v, cmd_w = 1.8, 2.0
        else:
            cmd_v, cmd_w = 0.25, 0.15

        ok, reason = self.validate(cmd_v, cmd_w, dt)
        if ok:
            self.v = cmd_v
            self.last_v = cmd_v
            self.accepted += 1
            self.status = "NORMAL" if not self.attack else "ATTACK_TEST"
            self.last_reason = "Comando aceito pela política de segurança"
        else:
            self.v = 0.0
            self.last_v = 0.0
            self.blocked += 1
            self.status = "ATTACK_BLOCKED" if self.attack else "SAFE_STOP"
            self.last_reason = reason
            if self.blocked == 1 or self.blocked % 10 == 0:
                self.write_log("SENTINELA BLOQUEOU: " + reason)

        self.theta += (0.15 if not self.attack else 0.0) * dt
        self.x += self.v * math.cos(self.theta) * 45 * dt
        self.y += self.v * math.sin(self.theta) * 45 * dt
        if self.x > 730: self.x = 60
        if self.x < 35: self.x = 715
        if self.y > 345: self.y = 55
        if self.y < 45: self.y = 340

        self.history.append((self.x, self.y))
        if len(self.history) > 30:
            self.history = self.history[-30:]
        self.canvas.coords(self.route_line, *sum(self.history, ()))

        color = "#dc3545" if self.status == "ATTACK_BLOCKED" else "#218838"
        self.canvas.coords(self.robot, self.x-13, self.y-13, self.x+13, self.y+13)
        self.canvas.itemconfigure(self.robot, fill=color)
        self.canvas.coords(self.heading, self.x, self.y,
                           self.x+25*math.cos(self.theta), self.y+25*math.sin(self.theta))

        self.status_label.configure(text="STATUS: " + self.status, foreground="#1b7f45" if self.status != "ATTACK_BLOCKED" else "#c0392b")
        self.metrics["status"].configure(text="Status: " + self.status, foreground="#1b7f45" if self.status != "ATTACK_BLOCKED" else "#c0392b")
        self.metrics["bridge"].configure(text="Bridge: " + self.bridge_status)
        self.metrics["route"].configure(text="Caminho: " + self.command_path)
        self.metrics["reason"].configure(text="Motivo: " + self.last_reason)
        self.metrics["accepted"].configure(text=f"Aceitos: {self.accepted}")
        self.metrics["blocked"].configure(text=f"Bloqueados: {self.blocked}")
        self.metrics["sim"].configure(text="Integração: Gazebo / ROS 2 pronta para bridge e tópicos de segurança")

        self.info.configure(
            text=(
                f"Velocidade aplicada: {self.v:.2f} m/s | "
                f"Angulação: {cmd_v:.2f} rad/s | "
                f"Comandos aceitos: {self.accepted} | "
                f"Bloqueados: {self.blocked}"
            )
        )
        self.root.after(100, self.tick)

def main(argv=None):
    parser = argparse.ArgumentParser(description="Cyber-Physical AMR Security Lab demo")
    parser.add_argument("--headless", action="store_true", help="Executa a simulação em modo terminal sem interface gráfica")
    args = parser.parse_args(argv)

    if args.headless or not is_gui_available():
        print("Ambiente sem interface gráfica; executando modo terminal.")
        for line in headless_mode():
            print(line)
        return

    root = tk.Tk()
    Demo(root)
    root.mainloop()


if __name__ == "__main__":
    main()
