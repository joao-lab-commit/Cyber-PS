"""Odometria + controle proporcional para seguir waypoints no armazém."""
import math
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist

def steering(x, y, yaw, goal):
    dx, dy = goal[0]-x, goal[1]-y
    dist = math.hypot(dx, dy)
    err = math.atan2(math.sin(math.atan2(dy, dx)-yaw), math.cos(math.atan2(dy, dx)-yaw))
    if dist < 0.25:
        return 0.0, 0.0, True
    return min(0.28, 0.22*dist) if abs(err)<0.6 else 0.0, max(-0.55,min(0.55,1.1*err)), False

class WaypointNav(Node):
    def __init__(self):
        super().__init__('waypoint_nav')
        self.pub=self.create_publisher(Twist, '/cmd_vel_untrusted',10)
        self.create_subscription(Odometry,'/odom',self.on_odom,10)
        self.create_timer(0.2,self.step)
        self.pose=None
        self.goals=[(1.0,0.0),(1.0,-1.0),(0.0,-1.0),(0.0,0.0)]
        self.index=0
        self.get_logger().info('Navegação por waypoints iniciada. Ambiente estático; sem desvio de obstáculos.')
    def on_odom(self,msg):
        q=msg.pose.pose.orientation
        yaw=math.atan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z))
        pos=msg.pose.pose.position
        self.pose=(pos.x,pos.y,yaw)
    def step(self):
        if self.pose is None:return
        v,w,done=steering(*self.pose,self.goals[self.index])
        if done:
            self.index=(self.index+1)%len(self.goals)
            self.get_logger().info('Waypoint alcançado; próximo: %s'%str(self.goals[self.index]))
        cmd=Twist();cmd.linear.x=v;cmd.angular.z=w
        self.pub.publish(cmd)

def main(args=None):
    rclpy.init(args=args);node=WaypointNav()
    try:rclpy.spin(node)
    except KeyboardInterrupt:pass
    finally:node.destroy_node();rclpy.shutdown()
