"""Controlled lab test: publishes safe and intentionally invalid commands."""
import time
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class AttackDemo(Node):
    def __init__(self):
        super().__init__('controlled_injection_test')
        self.pub = self.create_publisher(Twist, '/cmd_vel_untrusted', 10)
        self.count = 0
        self.timer = self.create_timer(1.0, self.send)
        self.get_logger().info('Teste controlado iniciado; publique somente no ambiente de laboratório.')

    def send(self):
        msg = Twist()
        if self.count < 4:
            msg.linear.x = 0.2
            msg.angular.z = 0.1
            self.get_logger().info('Enviando comando seguro de laboratório')
        elif self.count < 10:
            msg.linear.x = 1.5
            msg.angular.z = 2.0
            self.get_logger().warning('Tentativa simulada de injeção: comando fora da política')
        else:
            msg.linear.x = 0.0
            msg.angular.z = 0.0
            self.get_logger().info('Enviando parada')
        self.pub.publish(msg)
        self.count += 1
        if self.count > 12:
            self.timer.cancel()
            self.get_logger().info('Teste finalizado.')
            rclpy.shutdown()

def main(args=None):
    rclpy.init(args=args)
    node = AttackDemo()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if rclpy.ok():
            node.destroy_node()
            rclpy.shutdown()
