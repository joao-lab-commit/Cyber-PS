from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    share = get_package_share_directory('amr_security_lab')
    world = os.path.join(share, 'worlds', 'warehouse.sdf')
    return LaunchDescription([
        ExecuteProcess(
            cmd=['gz', 'sim', '-r', world],
            output='screen'
        ),
        Node(
            package='ros_gz_bridge',
            executable='parameter_bridge',
            arguments=[
                '/model/amr/cmd_vel@geometry_msgs/msg/Twist[gz.msgs.Twist',
                '/model/amr/odometry@nav_msgs/msg/Odometry[gz.msgs.Odometry',
            ],
            remappings=[
                ('/model/amr/cmd_vel', '/cmd_vel'),
                ('/model/amr/odometry', '/odom'),
            ],
            output='screen'
        ),
        Node(package='amr_security_lab', executable='sentry', output='screen'),
    ])
