# Plano de testes

## Testes rápidos — Windows
1. Inicie `python amr_security_demo.py`.
2. Confirme status `NORMAL` e deslocamento do robô.
3. Clique em **Iniciar ataque**; espere o status `ATTACK_BLOCKED` e o contador de bloqueios aumentar.
4. Confirme no log que o sentinela informa o motivo do bloqueio.
5. Clique em **Parar ataque**; confirme retorno ao movimento seguro.
6. Clique em **Resetar**; confirme contadores zerados.

## Testes ROS 2
Com o launch em execução, rode `ros2 run amr_security_lab attack_demo`. Observe `/security_status` e `/cmd_vel`. Comandos dentro dos limites devem ser aceitos; comandos acima dos limites devem resultar em parada segura e status de bloqueio.

## Matriz de evidências
| Caso | Entrada | Resultado esperado |
|---|---|---|
| T1 | velocidade linear 0,2 m/s | aceita |
| T2 | velocidade linear 1,5 m/s | bloqueada |
| T3 | velocidade angular 2,0 rad/s | bloqueada |
| T4 | NaN ou infinito | bloqueada |
| T5 | aceleração acima do limite | bloqueada |
| T6 | teste de injeção em ambiente isolado | status de ataque e comando não encaminhado |

A demo Windows é uma simulação didática de lógica; evidências de IMR devem ser gravadas no Gazebo.
