# Arquitetura

```text
Origem de comandos / teste de injeção
              |
              v
      /cmd_vel_untrusted
              |
              v
      [Sentry ROS 2]
      - valida finitude
      - limita velocidade
      - limita aceleração
      - gera status
              |
       aprovado | bloqueado
              v
          /cmd_vel -----------------> bridge ROS-Gazebo
              |                              |
              v                              v
       /security_status               AMR diferencial
              |                              |
              +------------> Dashboard/telemetria (extensão)
```

## Princípio de segurança
A origem de comandos de teste não publica diretamente no tópico que controla o robô. O único caminho permitido para `/cmd_vel` passa pelo sentinela. Em um sistema real, usar também controles de acesso, autenticação, isolamento de rede, parada de emergência e limites validados para o hardware.

## Paradigma funcional
A função `validate_command` é pura: recebe os valores do comando e o estado anterior necessário para validação, retorna uma decisão e uma justificativa, sem publicar mensagens, alterar estado global ou acessar a rede. A publicação ROS fica na camada de efeitos colaterais (`SentryNode`). Os limites são constantes e os dados de entrada são tratados como imutáveis.
